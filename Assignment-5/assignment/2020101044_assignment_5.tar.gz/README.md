# Assignment - 5

### q1 - **An alternate course allocation Portal**

### q2 - **The Clasico Experience**

### q3 - **Multithreaded client and server**

