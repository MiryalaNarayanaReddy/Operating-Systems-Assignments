#ifndef __MAIN_H__
#define __MAIN_H__

#include "utils.h"

void init();
void init_cd();
void init_process();
void init_signal();
void init_history();

#endif