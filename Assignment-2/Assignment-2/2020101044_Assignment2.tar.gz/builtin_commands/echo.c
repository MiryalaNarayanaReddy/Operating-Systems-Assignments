#include "echo.h"

void echo(char*args)
{
    printf("%s\n",args);
}