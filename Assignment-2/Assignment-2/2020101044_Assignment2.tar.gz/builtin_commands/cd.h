#ifndef __CD_H__
#define __CD_H__

#include "../Shell/utils.h"
bool changed_path;
void cd(char *path);

#endif