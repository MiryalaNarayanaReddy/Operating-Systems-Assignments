#ifndef __REPEAT_H__
#define __REPEAT_H__

#include "../Shell/utils.h"

void repeat(char*command);
int string_to_int(char *str);

#endif