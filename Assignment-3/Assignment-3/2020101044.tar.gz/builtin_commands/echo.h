#ifndef __ECHO_H__
#define __ECHO_H__

#include "../Shell/utils.h"

void echo(char *args);

#endif