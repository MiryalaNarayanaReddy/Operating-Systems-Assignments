#ifndef __PINFO_H__
#define __PINFO_H__

#include "../Shell/utils.h"

void pinfo(char *pid);

#endif