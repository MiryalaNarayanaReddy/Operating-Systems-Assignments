#ifndef __REPLAY_H__
#define __REPLAY_H__

#include "../Shell/utils.h"

void replay(char *command);

#endif