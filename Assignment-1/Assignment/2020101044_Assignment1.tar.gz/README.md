# os assignement-1

- buffer size in q1 and q2 is **```128KB```**
- q2 last two arguments must be **```non-zero single digits```**.

## q1
```
~$ gcc q1.c 
~$ ./a.out temp file.txt
```

## q2

```
~$ gcc q2.c
~$ ./a.out temp file.txt 5 3
```

## q3

```
~$ gcc q3.c
~$ ./a.out temp file.txt
```
